====================================
Hide Advance Search Options like "Filters", "Group By" and "Favorites" Buttons
====================================

This module hide Advance Search options like "Filters", "Group By" and "Favorites" 
For the Particular Group of Users
