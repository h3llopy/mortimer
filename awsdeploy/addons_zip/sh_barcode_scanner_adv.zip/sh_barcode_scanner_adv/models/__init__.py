# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from . import product_barcode

from . import res_company
from . import res_config_settings
from . import sale_order
from . import purchase_order
from . import stock_model
from . import account_invoice
from . import bom_barcode_scanner

