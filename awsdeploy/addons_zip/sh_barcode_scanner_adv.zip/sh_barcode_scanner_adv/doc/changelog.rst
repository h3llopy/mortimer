13.0.1 (21 FEB 2020)
=======
- initial release.

-  Added barcode scanning support of Invoice.

-  Added Inventory Adjustment Barcode Scanning.
-  Multi Barcode Supported.
-  Bug Fixed: in Sale, Discount not apply from pricelist when product added by Scanner.
	call line._onchange_discount() method in sale model file.
==> Seperate Advanced Version.
==> App technical name changed from sh_barcode_scanner to sh_barcode_scanner_adv.
