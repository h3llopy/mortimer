About
============
Do your time-wasting in sales, purchases, invoices, inventory, bill of material, scrap operations by manual product selection? So here are the solutions these modules useful do quick operations of sales, purchases, invoicing and inventory, bill of material, scrap using the barcode scanner. Multi barcode feature allows you to assign multi barcodes on the product. You no need to select a product and do one by one. scan it and you do! So be very quick in all operations of odoo and cheers!


User Guide
============
Blog: https://softhealer.com/blog/odoo-2/post/all-in-one-barcode-scanner-advance-415
Product: /shop/product/all-in-one-barcode-scanner-advance-422

Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list.
5) search module name and hit install button.

Any Problem with module?
=====================================
Please create your ticket here https://softhealer.com/support

Softhealer Technologies Doubt/Inquiry/Sales/Customization Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: support@softhealer.com
Website: https://softhealer.com
